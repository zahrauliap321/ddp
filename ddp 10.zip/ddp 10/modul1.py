phi = 3.14

def luas_lingkaran(r):
    return phi * r * r

def luas_segitiga(alas, tinggi):
    return 0.5 * alas * tinggi

def luas_persegi(sisi):
    return sisi * sisi