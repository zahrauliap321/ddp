phi = 3.14

def keliling_lingkaran(r):
    return 2 * phi * r

def keliling_segitiga(sisi1, sisi2, sisi3):
    return sisi1 + sisi2 + sisi3

def keliling_persegi(sisi):
    return 4 * sisi