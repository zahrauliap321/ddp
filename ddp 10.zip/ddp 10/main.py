import modul1
import modul2

phi = 3.14

def volume_tabung(jari_jari, tinggi):
    volume = phi * jari_jari * jari_jari * tinggi
    return volume

def volume_bola(jari_jari):
    volume = (4/3) * phi * jari_jari * jari_jari * jari_jari
    return volume

def volume_kubus(sisi):
    volume = sisi * sisi * sisi
    return volume


print("====================================")
print("Program Menghitung Bangun Datar dan Bangun Ruang")
print("====================================")
print("1. Luas Bangun Datar")
print("2. Keliling Bangun Datar")
print("3. Volume Bangun Ruang")
print("====================================")

pilihan = input("pilih menu (1/2/3): ")

if pilihan == "1":
    print()
    print("-- Luas Bangun Datar --")
    print("1. Lingkaran")
    print("2. Segitiga")
    print("3. Persegi")
    pilihan_bangun = input("pilih bangun (1/2/3): ")

    if pilihan_bangun == "1":
        jari_jari = float(input("masukkan jari-jari lingkaran: "))
        print("luas lingkaran =", modul1.luas_lingkaran(jari_jari))

    elif pilihan_bangun == "2":
        alas = float(input("masukkan alas segitiga: "))
        tinggi = float(input("masukkan tinggi segitiga: "))
        print("luas segitiga =", modul1.luas_segitiga(alas, tinggi))

    elif pilihan_bangun == "3":
        sisi = float(input("masukkan sisi persegi: "))
        print("luas persegi =", modul1.luas_persegi(sisi))

    else:
        print("pilihan tidak tersedia")

elif pilihan == "2":
    print()
    print("-- Keliling Bangun Datar --")
    print("1. Lingkaran")
    print("2. Segitiga")
    print("3. Persegi")
    pilihan_bangun = input("pilih bangun (1/2/3): ")

    if pilihan_bangun == "1":
        jari_jari = float(input("masukkan jari-jari lingkaran: "))
        print("keliling lingkaran =", modul2.keliling_lingkaran(jari_jari))

    elif pilihan_bangun == "2":
        sisi1 = float(input("masukkan sisi 1 segitiga: "))
        sisi2 = float(input("masukkan sisi 2 segitiga: "))
        sisi3 = float(input("masukkan sisi 3 segitiga: "))
        print("keliling segitiga =", modul2.keliling_segitiga(sisi1, sisi2, sisi3))

    elif pilihan_bangun == "3":
        sisi = float(input("masukkan sisi persegi: "))
        print("keliling persegi =", modul2.keliling_persegi(sisi))

    else:
        print("pilihan tidak tersedia")

elif pilihan == "3":
    print()
    print("-- Volume Bangun Ruang --")
    print("1. Tabung")
    print("2. Bola")
    print("3. Kubus")
    pilihan_bangun = input("pilih bangun (1/2/3): ")

    if pilihan_bangun == "1":
        jari_jari = float(input("masukkan jari-jari tabung: "))
        tinggi = float(input("masukkan tinggi tabung: "))
        print("volume tabung =", volume_tabung(jari_jari, tinggi))

    elif pilihan_bangun == "2":
        jari_jari = float(input("masukkan jari-jari bola: "))
        print("volume bola =", volume_bola(jari_jari))

    elif pilihan_bangun == "3":
        sisi = float(input("masukkan sisi kubus: "))
        print("volume kubus =", volume_kubus(sisi))

    else:
        print("pilihan tidak tersedia")

else:
    print("pilihan tidak tersedia")